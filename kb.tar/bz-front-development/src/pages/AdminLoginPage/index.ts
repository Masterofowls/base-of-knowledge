import {AdminLoginPageAsync} from "./ui/AdminLoginPage.async.tsx";

export {AdminLoginPageAsync as AdminLoginPage}