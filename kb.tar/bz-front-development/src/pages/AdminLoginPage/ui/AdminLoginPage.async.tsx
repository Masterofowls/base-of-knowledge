import {lazy} from "react";

// @ts-ignore
export const AdminLoginPageAsync = lazy(() => import('./AdminLoginPage'))