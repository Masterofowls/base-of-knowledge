import SmartRouter from './ui/SmartRouter';

export { SmartRouter };
