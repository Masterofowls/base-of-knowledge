import StudentDashboard from './ui/StudentDashboard';

export { StudentDashboard };
