import {AdminRegistationPageAsync} from "./ui/AdminRegistrationPage.async.tsx";

export {AdminRegistationPageAsync as AdminRegistrationPage}