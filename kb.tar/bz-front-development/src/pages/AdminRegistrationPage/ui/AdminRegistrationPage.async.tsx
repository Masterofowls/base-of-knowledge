import {lazy} from "react";

// @ts-ignore
export const AdminRegistationPageAsync = lazy(() => import('./AdminRegistrationPage'))