import {lazy} from "react";

// @ts-ignore
export const StudentLoginPageAsync = lazy(() => import('./StudentLoginPage'))