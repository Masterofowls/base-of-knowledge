import {StudentLoginPageAsync} from "./ui/StudentLoginPage.async.tsx";

export {StudentLoginPageAsync as StudentLoginPage}