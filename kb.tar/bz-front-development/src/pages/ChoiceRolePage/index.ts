import {ChoiceRolePageAsync} from "./ui/ChoiceRolePage.async.tsx";

export {ChoiceRolePageAsync as ChoiceRolePage}