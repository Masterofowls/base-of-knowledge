import {lazy} from "react";

// @ts-ignore
export const ChoiceRolePageAsync = lazy(() => import('./ChoiceRolePage'))