import {lazy} from "react";

// @ts-ignore
export const MainPageAsync = lazy(() => import('./MainPage'))