export { default as PostsList } from './ui/PostsList'


