import LatestPosts from "widgets/LatestPosts/ui/LatestPosts.tsx";

export {LatestPosts}