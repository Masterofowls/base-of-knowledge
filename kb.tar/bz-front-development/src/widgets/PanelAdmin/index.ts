import PanelAdmin from "./ui/PanelAdmin.tsx";

export {PanelAdmin}