import Footer from "./ui/Footer.tsx";

export {Footer}