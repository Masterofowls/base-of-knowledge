import QuickActionsAdmin from "./ui/QuickActionsAdmin.tsx";

export {QuickActionsAdmin}