// ESM-friendly Jest setup kept minimal for Supertest-only usage
